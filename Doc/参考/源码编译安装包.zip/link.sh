echo "拔下手机，输入lsusb，插上手机，再次输入lsusb，对比不同的地方，将不同的地方，例如：Bus 001 Device 018: ID 109b:911f中的  109b  记录下来，输入程序中"
read -p "输入手机识别码" phoneid
echo '0x'$phoneid | tee -a ~/.android/adb_usb.ini
echo 'SUBSYSTEM=="usb", ATTR{idVendor}==$phoneid, MODE="0666", GROUP="plugdev"' | sudo tee -a /etc/udev/rules.d/51-android.rules
sudo chmod a+r /etc/udev/rules.d/51-android.rules
sudo service udev restart

adb kill-server
adb start-server
