#!/bin/bash
echo "the following is install some depandent packages(if you installed,please input N/n and follow the prompt):"
##install adb
read -p "install adb(Y/N) " choice
if [ "$choice" == "Y" ] || [ "$choice" == "y" ]
then
	sudo apt-get install android-tools-adb
else
	if [ "choice" == "N" ] || [ "$choice" == "n" ]
	then
	read -p "please ensure your adb is in the system path.If not,please input your adb path:" adbpath
	PATH="$PATH:$adbpath" 
	export PATH 
	fi
fi
##install java1.7
read -p "install java1.7(Y/N) " choice
if [ "$choice" == "Y" ] || [ "$choice" == "y" ]
then
	sudo apt-get install openjdk-7-jre	
	sudo apt-get install openjdk-7-jdk
else
	if [ "choice" == "N" ] || [ "$choice" == "n" ]
	then
	read -p "please ensure your java is in the system path and the version is over 1.7.If not,please input your java path:" javapath
	PATH="$PATH:$javapath" 
	export PATH 
	fi
fi
##install python3
read -p "install python3(Y/N) " choice
if [ "$choice" == "Y" ] || [ "$choice" == "y" ]
then
	sudo apt-get install python3
else
	if [ "choice" == "N" ] || [ "$choice" == "n" ]
	then
	echo "please ensure your python is in the system path and the version is over 3."
	fi
fi
##install apache2
read -p "install apache2(Y/N) " choice
if [ "$choice" == "Y" ] || [ "$choice" == "y" ]
then
	sudo apt-get install apache2
	sudo cp -f apache2.conf /etc/apache2/
	sudo cp -f 000-default.conf /etc/apache2/sites-available
	sudo sed -i "s&~&$HOME&g" /etc/apache2/apache2.conf
	sudo sed -i "s&~&$HOME&g" /etc/apache2/sites-available/000-default.conf		
	sudo a2enmod cgid
	sudo service apache2 restart	
else
	if [ "choice" == "N" ] || [ "$choice" == "n" ]
	then
	echo "please ensure the version of your apache2 is over 2 and change your settings which can run cgi(you can search it on the Internet).Please read readme and change something."
	fi
fi
##install nw
read -p "install nw(Y/N) " choice
if [ "$choice" == "Y" ] || [ "$choice" == "y" ]
then
	sudo apt-get install netrw
else
	if [ "choice" == "N" ] || [ "$choice" == "n" ]
	then
	read -p "please ensure your netrw is in the system path if not,please input your path:" nwpath
	PATH="$PATH:$nwpath" 
	export PATH 
	fi
fi
cp -rf androidhelperspace ~/
cd  androidhelperspace/

zip -r androidhelper.zip ./*

mv androidhelper.zip ~/androidhelper.nw
cd  ../nwjs/
cat nw ~/androidhelper.nw > androidhelper
chmod +x androidhelper

rm ~/androidhelper.nw 
cp icudtl.dat ~/icudtl.dat
cp nw.pak ~/nw.pak
mv androidhelper ~/androidhelper
sudo chown -R www-data:www-data ~/androidhelperspace/data ~/androidhelperspace/image
echo "please add the following to  /etc/sudoers:"
echo "www-data	ALL=(ALL:ALL) NOPASSWD:ALL"
